package tomadaDecisao;

public class salario {

}
