package tomadaDecisao;
import java.util.Scanner;
public class parouimpar {
	public static void main(String[] args) {
	Scanner ler = new Scanner (System.in);
	int numero, par, impar;
	System.out.print("Digite o numero desejado: ");
	numero = ler.nextInt();
	
	if (numero%2==0) {
		System.out.print("Par");
	}else {
		System.out.print("Impar");
	}
	ler.close();
	}
}
