package tomadaDecisao;
import java.util.Scanner;
public class eleicao {
	public static void main(String[] args) {
	Scanner ler = new Scanner (System.in);
	int anoNascimento, anoEleicao, idade;
	System.out.print("Digite o ano de seu nascimento: ");
	anoNascimento = ler.nextInt();
	System.out.print("Digite o ano da próxima eleição: ");
	anoEleicao = ler.nextInt();
	idade = anoEleicao - anoNascimento;
	System.out.println("Sua idade será = " + idade + " anos.");
	
	if(idade>=16) {
		System.out.println("Eleitor ;) ");
	}else {
		System.out.println("Não eleitor :( ");
	}
	
	
	}
}
