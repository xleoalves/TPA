import java.util.Scanner;

public class exercicio2 {
	public static void main(String[] args) {
		Scanner ler = new Scanner (System.in);
		int a,b, c;
		System.out.println("insira um numero para obter seu valor fatorial ");
		a = ler.nextInt();
		b = a;
		c = 1;
		while (b > 1) {
			c = c * b;
			b--;
		}System.out.println("o valor fatorial �: " + c);
	}

}
