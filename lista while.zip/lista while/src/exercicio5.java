import java.util.Scanner;
public class exercicio5 {
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int i=1, n, divi=0;
		
		System.out.println("digigite o numero para ver se ele � numero primo ou composto: ");
		n = ler.nextInt();
		
		while (i <= n) {	
			if(n % i == 0) {
				divi = divi + 1;
			}
			i = i + 1;
		}
		if (divi == 2) {
			System.out.println("esse numero � primo ");
		}else {
			System.out.println("esse numero � composto");
		}
		ler.close();
	}
}
