import java.util.Scanner;
public class exercicio4 {
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		double base, potencial;
		int ex, cont;
		System.out.println("escreva o numero como base para o calculo: ");
		base = ler.nextDouble();
		System.out.println("escreva o numero como expoente para o calculo: ");
		ex = ler.nextInt();
		potencial = 1;
		cont = 0;
		while (cont < ex) {
			potencial = potencial * base;
		    cont++;
		}System.out.println("base " + base + "ao expoente " + ex + "resulta na potencia " + potencial );
	}
}
