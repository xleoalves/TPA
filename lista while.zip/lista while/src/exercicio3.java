
public class exercicio3 {
	public static void main(String[] args) {
		int n=1, i=1;
		while (n < 10) {
			while (i < 11) {
				System.out.println(n + "x" + i + "=" + (n*i));
				i++;
			} 
			System.out.println();
			n++;
			i = 1;
			while (i<11) {
				System.out.println(n + "x" + i + "=" + (n*i));
				i++;
			}
			
		} 
		
	}

}
