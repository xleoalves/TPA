
public class exercicio1 {
	public static void main(String[] args) {
		double altjoao, altpedro, cresjoao, crespedro;
		int anos;
		anos = 0;
		altjoao = 1.34;
		altpedro = 1.45;
		cresjoao = 0.025;
		crespedro = 0.020;
		while (altjoao < altpedro){
			altjoao = altjoao + cresjoao;
			altpedro = altpedro + crespedro;
			anos++;
		} System.out.println("Jo�o ficara maior que predro em " + anos + "anos");
	}
}
