import java.util.Scanner;
public class exercicio2 {
	public static void main(String[] args) {
	Scanner teleo = new Scanner(System.in);
		int ant, atu, prox;
		while(prox == atu) {
			atu = teleo.nextInt();
			ant = atu - 1;
			prox = atu + ant;
		}
	
	}
}
