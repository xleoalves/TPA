import java.util.Scanner;
public class exercicio1 {
	public static void main(String[] args) {
		int idade,pessoas = 15, calculo;
		Scanner teleo = new Scanner(System.in);
		System.out.println("coloque a idade: ");
		idade = teleo.nextInt();
		System.out.println("coloque a proxima idade: ");
		while (pessoas == 15) {
			if (idade <= 15) {
			System.out.println("1� faixa et�ria");
		}else if ( idade < 30) {
			System.out.println("2� faixa et�ria");
		}
		
		}
	}

}
