import java.util.Scanner;
public class escolinha {
	public static void main(String[] args) {
		Scanner in = new Scanner (System.in);
		int id;
		System.out.println("Informe sua idade:");
		id = in.nextInt();
		switch(id) {
		    
		    case 6:
		    	System.out.println("sua categoria é: Dente de Leite");
		    	break;
		    case 7:
		    	System.out.println("sua categoria é: Junior");
		    	break;
		    case 8:
		    	System.out.println("sua categoria é: Junior max");
		    	break;
		    case 9:
		    	System.out.println("sua categoria é: Junior master");
		    	break;
		    case 10:
		    	System.out.println("sua categoria é: Master");
		    	break;
		    default:
		        case 1:
		        case 2:
		        case 3:
		        case 4:
		        case 5:
		    	System.out.println("Idade invalida");
		    	
		    	 
			
		}
	}

}
