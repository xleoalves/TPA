import java.util.Scanner;
public class notas {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int q, mb, b, r, i,porcmb, porcb, porcr, porci, nota;
		System.out.println("digitos// 1 = MB || 2 = B || 3 = R || 4 = I");
		System.out.print("digite a quantidade de alunos: ");
		q = in.nextInt();
		System.out.print("de qual nota vc quer saber?: ");
		nota = in.nextInt();
		switch (nota) {
		case 1:
			System.out.print("digite quantos alunos tiraram MB: ");
			mb = in.nextInt();
			porcmb = (mb*100)/q;
			System.out.println("a porcentagem dos alunos que tiraram a nota MB �: " + porcmb + "%");
			break;
		case 2:
			System.out.print("digite quantos alunos tiraram B: ");
			b = in.nextInt();
			porcb = (b*100)/q;
			System.out.println("a porcentagem dos alunos que tiraram a nota B �: " + porcb + "%");
			break;
		case 3:
			System.out.print("digite quantos alunos tiraram R: ");
			r = in.nextInt();
			porcr = (r*100)/q;
			System.out.println("a porcentagem dos alunos que tiraram a nota R �: " + porcr + "%");
			break;
		case 4:
			System.out.print("digite quantos alunos tiraram I: ");
			i = in.nextInt();
			porci = (i*100)/q;
			System.out.println("a porcentagem dos alunos que tiraram a nota I �: " + porci + "%");
			break;
		}
	}
}
