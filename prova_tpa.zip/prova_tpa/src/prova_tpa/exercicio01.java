package prova_tpa;
import java.util.Scanner;
public class exercicio01 {
	public static void main(String[] args) {
		Scanner ler = new Scanner (System.in);
		double peso, preco;
		System.out.println("digite o peso do peixe em quilograma: ");
		peso = ler.nextDouble();
		if (peso <= 3000) {
			preco = (peso*25)/1000;
			System.out.println("seu peixe custa: R$" + preco);
		}else if (peso <= 5000) {
			preco = (peso*24)/1000;
			System.out.println("seu peixe custa: R$" + preco);
		}else if (peso <= 10000) {
			preco = (peso*23)/1000;
			System.out.println("seu peixe custa: R$" + preco);
		}else {
			preco = ((peso*20)/1000)+30;
			System.out.println("seu peixe custa: R$" + preco);
		}
	}

}
