package algoritimos;
import java.util.Scanner;
public class cashback {
public static void main(String[] args) {
	Scanner ler= new Scanner(System.in);
	double valor,cashback;
	System.out.println("informe o valor de sua compra");
	valor=ler.nextDouble();
	if (valor<=100) {
		cashback=valor*5/100;
		System.out.println("seu cashback �" + cashback);
	}else if(valor<=1000) {
		cashback=valor*8/100;
		System.out.println("seu cashback �" +cashback);
	}else if (valor<=2000) {
		cashback=valor*10/100;
		System.out.println("seu cashback �" +cashback);
	}else if (valor<=5000) {
		cashback=valor*12.5/100;
		System.out.println("seu cashback �" +cashback);
	}else {
		cashback=valor*15/100;
		System.out.println("seu cashback � " +cashback);
	}
}
}
