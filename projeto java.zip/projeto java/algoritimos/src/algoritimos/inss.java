package algoritimos;
import java.util.Scanner;
public class inss {
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		double inss,  renda;
		System.out.println("Informe a sua renda:");
		renda = ler.nextInt();
		if (renda<=1412) {
			inss=(renda*7.5)/100;
			System.out.println("O valor do inss �: " + inss);
		}else if (renda<=2666.68) {
			inss=(renda*9)/100;
			System.out.println("O valor do inss �: " + inss);
		}else if (renda<=4000.03) {
			inss=(renda*12)/100;
			System.out.println("O valor do inss �: " + inss);
		}else if (renda<=7786.02) {
			inss=(renda*14)/100;
			System.out.println("O valor do inss �: " + inss);
		}else {
			inss=(renda*16)/100;
			System.out.println("O valor do inss �: " + inss);
					
			
		}
		    
		
	}

}
