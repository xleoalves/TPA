package algoritimos;
import java.util.Scanner;
public class switchCase {
public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
	int d;
	System.out.println("Digite um n�mero inteiro para sabe o dia");
	d = in.nextInt();
	//In na estrutura de Switch case
	switch(d) {
	case 1:
	case 2:
		System.out.println("Segunda n�o pode");
		break;
	case 3:
	case 4:
		System.out.println("Ter�a n�o pode");
		break;
	case 5:
	case 6:
		System.out.println("Quarta n�o pode");
		break;
	case 7:
	case 8:
		System.out.println("Quinta n�o pode");
		break;
	case 9:
	case 0:
		System.out.println("Sexta n�o pode");
		break;
	default:
		System.out.println("N�mero inv�lido");
		
	}
	
	
}

}
