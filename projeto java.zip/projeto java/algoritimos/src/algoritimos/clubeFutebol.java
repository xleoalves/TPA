package algoritimos;
import java.util.Scanner;
public class clubeFutebol {
public static void main(String[] args) {
	Scanner ler=new Scanner(System.in);
	int id;
	//Inteira
	System.out.println("Escreva sua idade");
	id = ler.nextInt();
	if(id<=6) {
	System.out.println("Categoria dente de leite");
	}else if(id<=10) {
		System.out.println("voc� participar� da categoria infantil 1");
    }else if(id<=14) {
	System.out.println("voc� participar� da categoria infantil 2");
    }else if(id<=16) {
	System.out.println("voc� participar� da categoria juvenil 1");
    }else if(id<=17) {
	System.out.println("voc� participar� da categoria juvenil 2");
    }else  {
	System.out.println("Idade n�o permitida");
    }
}
}
