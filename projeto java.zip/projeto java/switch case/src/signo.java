import java.util.Scanner;
public class signo {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int m, d;
		System.out.println("Informe o m�s: ");
		m = in.nextInt();
		System.out.println("Informe o dia: ");
		d = in.nextInt();
		switch(m) {	
		case 1:
			if (d<21) {
				System.out.println("Capric�rnio");
			}else  {
				System.out.println("Aqu�rio");
			}
			break;
		case 2:	
			if (d<20) {
				 System.out.println("Aqu�rio");
			}else {
				System.out.println("Peixes");
			}
			break;
		case 3:
			if (d<20) {
				System.out.println("Peixes");
			}else {
				System.out.println("�ries");
			}
		    break;
		case 4:
			if (d<21) {
				System.out.println("�ries");
			}else {
				System.out.println("Touro");
			}
		    break;
		case 5:
			if (d<21) {
				System.out.println("Touro");
			}else {
				System.out.println("G�meos");
			}
		    break;
		case 6:
			if (d<21) {
				System.out.println("G�meos");
			}else {
				System.out.println("C�ncer");
			}
			break;
		case 7:
			if (d<21) {
				System.out.println("C�ncer");
			}else {
				System.out.println("Le�o");
			}
		}
		
		 
		
		
	}

}
