import java.util.Scanner;
public class escolinha {
	public static void main(String[] args) {
		Scanner in = new Scanner (System.in);
		int id;
		System.out.println("Informe sua idade:");
		id = in.nextInt();
		switch(id) {
		    
		    case 6:
		    	System.out.println("Dente de Leite");
		    	break;
		    case 7:
		    	System.out.println("J�nior");
		    	break;
		    case 8:
		    	System.out.println("J�nior max");
		    	break;
		    case 9:
		    	System.out.println("J�nior master");
		    	break;
		    case 10:
		    	System.out.println("Master");
		    	break;
		    default:
		        case 1:
		        case 2:
		        case 3:
		        case 4:
		        case 5:
		    	System.out.println("Idade inv�lida");
		    	
		    	 
			
		}
	}

}
