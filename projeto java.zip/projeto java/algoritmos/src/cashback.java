package algoritimos;
import java.util.*;
public class cashback {
public static void main(String[] args) {
	Scanner ler= new Scanner(System.in);
	double compra,cashback;
	System.out.println("informe o valor de sua compra");
	compra=ler.nextDouble();
	if (compra<=100) {
		cashback=compra*5/100;
		System.out.println("seu cashback �" + cashback);
	}else if(compra==101 OU compra <=1000) {
		cashback=compra*8/100;
		System.out.println("seu cashback �" +cashback);
	}else if (compra==1001 OU compra<=2000) {
		cashback=compra*10/100;
		System.out.println("seu cashback �" +cashback);
	}else if (compra==2001 OU compra<=5000) {
		cashback=compra*12.5/100;
		System.out.println("seu cashback �" +cashback);
	}else (compra>5000){
		cashback=compra*15/100;
		System.out.println("seu cashback �" +cashback);
	}
}
}